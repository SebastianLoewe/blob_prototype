Put your libraries inside here. 
* list of P5.js libraries: https://p5js.org/libraries/

Don't forget to reference in 'index.html'. Example:
```
 <script src="libraries/p5.pdf.js"></script>
```